import { TestBed } from '@angular/core/testing';

import { EwalletService } from './ewallet.service';

describe('EwalletService', () => {

  let ewallet: EwalletService;

  beforeEach(() => {
    ewallet = new EwalletService(3000);

  });


  afterEach(() => {
    ewallet = null;
  })



  it('should test doshopping method', () => {
    let amount = 1000;
    ewallet.doShopping(amount);
    let actual = ewallet.getBalance();
    expect(actual).toBe(2000);
  });

  it('it should deposit money', () => {
    let depositamount = 1000;
    ewallet.depositMoney(depositamount);
    let actual = ewallet.getBalance();
    expect(actual).toBe(4000);


  });

  it('getbalance() should return total balance', () => {
    let total = 3000;
    let actual = ewallet.getBalance();
    expect(actual).toBe(total);


  });

});
