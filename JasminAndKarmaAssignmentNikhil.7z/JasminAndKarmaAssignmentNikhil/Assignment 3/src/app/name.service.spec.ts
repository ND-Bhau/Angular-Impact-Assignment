import { NameService } from './name.service';

describe('NameService', () => {
  let name: NameService;

  beforeAll(() => {
    name = new NameService();
  });

  afterAll(() => {
    name = null;
  });

  it('should be Array of Names', () => {
    let result = ["Nikhil", "Suresh"];
    name.add("Nikhil");
    name.add("Suresh");

    expect(name.names).toEqual(result);
  });
  it('should be Clear', () => {
    let result = [];
    name.clear();

    expect(name.names).toEqual(result);
  });
});
