import { AcademicsPipe } from './academics.pipe';

describe('AcademicsPipe', () => {
  let academics: AcademicsPipe;

  beforeAll(() => {
    academics = new AcademicsPipe();
  })

  afterAll(() => {
    academics = null;
  })

  it('Test should return Distinction', () => {
    let actual = academics.transform(75);
    expect(actual).toBe("75 (Distinction)");
  })

  it('Test should return First Class', () => {
    let actual = academics.transform(65);
    expect(actual).toBe("65 (First Class)");
  })

  it('Test should return Second Class', () => {
    let actual = academics.transform(55);
    expect(actual).toBe("55 (Second Class)");
  })

  it('Test should return Pass', () => {
    let actual = academics.transform(45);
    expect(actual).toBe("45 (Pass)");
  })

  it('Test should return Fail', () => {
    let actual = academics.transform(30);
    expect(actual).toBe("30 (Fail)");
  })
});


