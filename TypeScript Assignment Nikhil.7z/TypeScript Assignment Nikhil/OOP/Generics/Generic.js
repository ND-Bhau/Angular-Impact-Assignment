function add(E1, E2) {
    return E1 + E2;
}
console.log("Addition of numbers : ".concat(add(3, 7)));
console.log("string concatination : ".concat(add("Nikhil", " Dhamnerkar")));
// -------------------------------------------------------------------------------
function addition(add1, add2) {
    if (typeof add1 === 'number' && typeof add2 === 'number') {
        return add1 + add2;
    }
    else if (typeof add1 === 'string' && typeof add2 === 'string') {
        return add1.concat(" ", add2);
    }
    else {
        return "Please enter number or string paramerters";
    }
}
console.log("Addition of numbers : " + addition(7, 7));
console.log("string concate " + addition("Nikhil", "Dhamnerkar"));
