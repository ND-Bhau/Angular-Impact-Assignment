function add(no1: number, no2: number): number;
function add(fname: string, lname: string): string;

function add(E1: any, E2: any): any {
    return E1 + E2;
}

console.log(`Addition of numbers : ${add(3, 7)}`);
console.log(`string concatination : ${add("Nikhil", " Dhamnerkar")}`);




// -------------------------------------------------------------------------------


function addition<T extends number | string>(add1: T, add2: T) {
    if (typeof add1 === 'number' && typeof add2 === 'number') {
        return add1 + add2;
    }
    else if (typeof add1 === 'string' && typeof add2 === 'string') {
        return add1.concat(" ", add2);
    }
    else {
        return "Please enter number or string paramerters";
    }
}


console.log("Addition of numbers : " + addition<number>(7, 7));
console.log("string concate " +addition<string>("Nikhil", "Dhamnerkar"));
