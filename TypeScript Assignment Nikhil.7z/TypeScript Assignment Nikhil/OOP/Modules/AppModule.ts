import { Sparrow, Superman, Missile } from "./ClassModule";
import FlyInterface from "./InterfaceModule";


export let ForSparrow: FlyInterface = new Sparrow();
export let ForSuperman: FlyInterface = new Superman();
export let ForMissile: FlyInterface = new Missile();

export function printall() {
    console.log(
        [
            `sparrow class : ${ForSparrow.Fly()}`,
            `superman class : ${ForSuperman.Fly()}`,
            `missile class : ${ForMissile.Fly()}`
        ]
    )
}