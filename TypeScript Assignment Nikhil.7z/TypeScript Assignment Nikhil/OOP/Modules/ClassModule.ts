import FlyInterface from "./InterfaceModule";

export class Sparrow implements FlyInterface {
    Fly(): string {
        return 'Sparrow can fly';
    }
}

export class Superman implements FlyInterface {
    Fly(): string {
        return 'Superman can fly';
    }
}

export class Missile implements FlyInterface {
    Fly(): string {
        return 'Missile can fly';
    }
}
