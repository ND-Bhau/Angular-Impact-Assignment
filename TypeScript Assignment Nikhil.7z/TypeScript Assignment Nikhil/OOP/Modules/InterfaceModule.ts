export default interface IFly {
    Fly(): string;
}


