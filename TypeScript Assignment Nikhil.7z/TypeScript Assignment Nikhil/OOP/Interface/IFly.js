"use strict";
exports.__esModule = true;
exports.Missile = exports.Superman = exports.Sparrow = void 0;
var Sparrow = /** @class */ (function () {
    function Sparrow() {
    }
    Sparrow.prototype.Fly = function () {
        return 'Sparrow can fly';
    };
    return Sparrow;
}());
exports.Sparrow = Sparrow;
var Superman = /** @class */ (function () {
    function Superman() {
    }
    Superman.prototype.Fly = function () {
        return 'Superman can fly';
    };
    return Superman;
}());
exports.Superman = Superman;
var Missile = /** @class */ (function () {
    function Missile() {
    }
    Missile.prototype.Fly = function () {
        return 'Missile can fly';
    };
    return Missile;
}());
exports.Missile = Missile;
var ForSparrow = new Sparrow();
var ForSuperman = new Superman();
var ForMissile = new Missile();
console.log([
    "sparrow class : ".concat(ForSparrow.Fly()),
    "superman class : ".concat(ForSuperman.Fly()),
    "missile class : ".concat(ForMissile.Fly())
]);
