interface IFly {
    Fly(): string;
}

class Sparrow implements IFly {
    Fly(): string {
        return 'Sparrow can fly';
    }
}

class Superman implements IFly {
    Fly(): string {
        return 'Superman can fly';    }
}

class Missile implements IFly {
    Fly(): string {
        return 'Missile can fly';    }
}

let ForSparrow:IFly = new Sparrow();
let ForSuperman:IFly = new Superman();
let ForMissile:IFly = new Missile();

console.log(
    [
        `sparrow class : ${ForSparrow.Fly()}`,
        `superman class : ${ForSuperman.Fly()}`,
        `missile class : ${ForMissile.Fly()}`
    ]
)

