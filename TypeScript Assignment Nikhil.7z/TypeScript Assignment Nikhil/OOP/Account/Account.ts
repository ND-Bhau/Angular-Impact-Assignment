class Account {
    accountID: number;

    name: string;

    initialBalance: number;

    private static accountcount: number = 1;

    static CountAccounts(): number {
        return this.accountcount++;
    }
    /**
     * To be initilised the default fields
     */
    constructor(id: number = 1, name: string = 'Jay Khurana', initialbalance: number = 10000.0) {
        this.accountID = id;
        this.name = name;
        this.initialBalance = initialbalance;
        Account.CountAccounts();  // optional
    }

    WithDraw(amt: number) {
        if (amt < this.initialBalance) {
            this.initialBalance -= amt;
            // console.log(`Hi ${this.Name} \n ${amt} is withdrow form your account \n your total balance is ${this.InitialBalance}`);
            this.log(`Hi ${this.name} \n ${amt} is withdrow form your account \n your total balance is ${this.initialBalance}`);
        } else {
            // console.log(`Hi ${this.Name} you dont have enough balance.\n You balance is ${this.InitialBalance}`);
            this.log(`Hi ${this.name} you dont have enough balance.\n You balance is ${this.initialBalance}`);
        }
    }

    Deposit(amt: number) {
        this.initialBalance += amt;
        // console.log(`Hi ${this.Name} \n ${amt} is credited to your account \n your total balance is ${this.InitialBalance}`);
        this.log(`Hi ${this.name} \n ${amt} is credited to your account \n your total balance is ${this.initialBalance}`);
    }

    private log(msg: string) {
        console.log(msg);
    }


}


// objects  => 1 way

// let AccountObj1 = new Account(101, "Nikhil Dhamnerkar", 12000);
// let AccountObj2 = new Account(102, "Amit Sonavane", 13000);
// let AccountObj3 = new Account(103, "Yogesh Pawar", 14000);

// let arry = [AccountObj1, AccountObj2, AccountObj3];

// arry.forEach(element => {
//     console.log('\n')
//     element.WithDraw(1000);
//     element.Deposit(2000);
// });

// object => 2nd way

console.log('\n --------------------------------------------\n');

let AccArray = [];
AccArray.push(new Account(101, "Nikhil Dhamnerkar", 12000));
AccArray.push(new Account(102, "Amit Sonavane", 13000));
AccArray.push(new Account(103, "Yogesh Pawar", 14000));


AccArray.forEach(element => {
    console.log('\n')
    element.WithDraw(200);
    element.Deposit(800);
});



