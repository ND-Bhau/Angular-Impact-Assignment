var Account = /** @class */ (function () {
    /**
     * To be initilised the default fields
     */
    function Account(id, name, initialbalance) {
        if (id === void 0) { id = 1; }
        if (name === void 0) { name = 'Jay Khurana'; }
        if (initialbalance === void 0) { initialbalance = 10000.0; }
        this.accountID = id;
        this.name = name;
        this.initialBalance = initialbalance;
        Account.count();
    }
    Account.count = function () {
        return this.accountcount++;
    };
    Account.prototype.WithDraw = function (amt) {
        if (amt < this.initialBalance) {
            this.initialBalance -= amt;
            // console.log(`Hi ${this.Name} \n ${amt} is withdrow form your account \n your total balance is ${this.InitialBalance}`);
            this.log("Hi ".concat(this.name, " \n ").concat(amt, " is withdrow form your account \n your total balance is ").concat(this.initialBalance));
        }
        else {
            // console.log(`Hi ${this.Name} you dont have enough balance.\n You balance is ${this.InitialBalance}`);
            this.log("Hi ".concat(this.name, " you dont have enough balance.\n You balance is ").concat(this.initialBalance));
        }
    };
    Account.prototype.Deposit = function (amt) {
        this.initialBalance += amt;
        // console.log(`Hi ${this.Name} \n ${amt} is credited to your account \n your total balance is ${this.InitialBalance}`);
        this.log("Hi ".concat(this.name, " \n ").concat(amt, " is credited to your account \n your total balance is ").concat(this.initialBalance));
    };
    Account.prototype.log = function (msg) {
        console.log(msg);
    };
    Account.accountcount = 1;
    return Account;
}());
// objects  => 1 way
// let AccountObj1 = new Account(101, "Nikhil Dhamnerkar", 12000);
// let AccountObj2 = new Account(102, "Amit Sonavane", 13000);
// let AccountObj3 = new Account(103, "Yogesh Pawar", 14000);
// let arry = [AccountObj1, AccountObj2, AccountObj3];
// arry.forEach(element => {
//     console.log('\n')
//     element.WithDraw(1000);
//     element.Deposit(2000);
// });
// object => 2nd way
console.log('\n --------------------------------------------\n');
var AccArray = [];
AccArray.push(new Account(101, "Nikhil Dhamnerkar", 12000));
AccArray.push(new Account(102, "Amit Sonavane", 13000));
AccArray.push(new Account(103, "Yogesh Pawar", 14000));
AccArray.forEach(function (element) {
    console.log('\n');
    element.WithDraw(200);
    element.Deposit(800);
});
