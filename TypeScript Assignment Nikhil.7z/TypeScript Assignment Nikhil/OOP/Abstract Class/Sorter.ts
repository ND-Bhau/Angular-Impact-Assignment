abstract class Sorter {
    abstract sort(): string;
}

class linear extends Sorter {
    sort(): string {
        return 'linear sort implimented';
    }
}

class bubble extends Sorter {
    sort(): string {
        return 'bubble sort implemented';
    }
}


let Ilinear: Sorter = new linear();
let IBubble: Sorter = new bubble();

let ArrayObj =[];
ArrayObj.push(Ilinear);
ArrayObj.push(IBubble);


ArrayObj.forEach(element => {
    console.log(element.sort());
});

