var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Sorter = /** @class */ (function () {
    function Sorter() {
    }
    return Sorter;
}());
var linear = /** @class */ (function (_super) {
    __extends(linear, _super);
    function linear() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    linear.prototype.sort = function () {
        return 'linear sort implimented';
    };
    return linear;
}(Sorter));
var bubble = /** @class */ (function (_super) {
    __extends(bubble, _super);
    function bubble() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    bubble.prototype.sort = function () {
        return 'bubble sort implemented';
    };
    return bubble;
}(Sorter));
// let sorterArray:Sorter[] = [];
// sorterArray.push(new Sorter());
// sorterArray.push(new Sorter());
var Ilinear = new linear();
var IBubble = new bubble();
var ArrayObj = [];
ArrayObj.push(Ilinear);
ArrayObj.push(IBubble);
ArrayObj.forEach(function (element) {
    console.log(element.sort());
});
console.log('=================================');
