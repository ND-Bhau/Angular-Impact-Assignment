function Add(no1, no2) {
    return no1 + no2;
}
function Sub(no1, no2) {
    return no1 - no2;
}
function Multi(no1, no2) {
    return no1 * no2;
}
function Divide(no1, no2) {
    if (no2 != 0) {
        return no1 / no2;
    }
    console.log('Second no should not be zero');
    return 0;
}
console.log('\n---------------------------------------------\n');
var Addition = Add(3, 7);
console.log("Addition of the No is : ".concat(Addition));
var Substraction = Sub(3, 7);
console.log("Substraction of the No is : ".concat(Substraction));
var Multiplication = Multi(3, 7);
console.log("Multiplication of the No is : ".concat(Multiplication));
var Division = Divide(3, 7);
console.log("Division of the No is : ".concat(Division));
console.log('\n---------------------------------------------\n');
