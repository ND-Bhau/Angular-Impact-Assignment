function Add(no1: number, no2: number): number {
    return no1 + no2;
}

function Sub(no1: number, no2: number): number {
    return no1 - no2;
}

function Multi(no1: number, no2: number): number {
    return no1 * no2;
}

function Divide(no1: number, no2: number): number {
    
    if (no2 != 0) {
        return no1 / no2;
    }

    console.log('Second no should not be zero')
    return 0;
}

console.log('\n---------------------------------------------\n');

let Addition = Add(3, 7);
console.log(`Addition of the No is : ${Addition}`);

let Substraction = Sub(3, 7);
console.log(`Substraction of the No is : ${Substraction}`);

let Multiplication = Multi(3, 7);
console.log(`Multiplication of the No is : ${Multiplication}`);

let Division = Divide(3, 7);
console.log(`Division of the No is : ${Division}`);
console.log('\n---------------------------------------------\n');

