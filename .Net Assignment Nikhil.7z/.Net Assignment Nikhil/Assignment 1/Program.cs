﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a List of doubles.Add some doubles to it.Display the elements of this list.

            List<double> doubleList = new List<double>() { 10.1, 20.2, 30.3, 40.4, 50.5 };

            foreach (var item in doubleList)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();

            List<Employee> employees = new List<Employee>();

            Employee employeedetails = GetEmployeeDetailsdetails();

            employees.Add(employeedetails);

            employeedetails = GetEmployeeDetailsdetails();

            employees.Add(employeedetails);


            foreach (var item in employees)
            {
                string toPrint = "Employee ID : " + item.EmployeeId + " Name : " + item.FirstName + " " + item.LastName + " Date of Joining : "
                    + item.DateOfJoining;
                Console.WriteLine(toPrint);
            }

            Console.ReadKey();
        }

        private static Employee GetEmployeeDetailsdetails()
        {
            Employee data = new Employee();
            Console.WriteLine("Enter Employee ID : ");
            data.EmployeeId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter First Name : ");
            data.FirstName = Console.ReadLine();

            Console.WriteLine("Enter Last Name : ");
            data.LastName = Console.ReadLine();

            data.DateOfJoining = DateTime.Now;

            return data;
        }
    }
}
