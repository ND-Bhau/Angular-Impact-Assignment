﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    public class CustomerOrder
    {
        public int orderid { get; set; }
        public DateTime orderdate { get; set; }
        public string custname { get; set; }
        public double orderamount { get; set; }
        public string disapatchcity { get; set; }
    }
}
