﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    public class CustOrder
    {
        public int orderid { get; set; }
        public int custid { get; set; }
        public double orderamount { get; set; }
        public string disapatchcity { get; set; }
    }
}
