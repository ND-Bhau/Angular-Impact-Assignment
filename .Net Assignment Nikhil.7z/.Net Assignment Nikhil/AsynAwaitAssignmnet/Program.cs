﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsynAwaitAssignmnet
{
    class Program
    {
        static void Main(string[] args)
        {
            Task task = new Task(CallSomeMethod);
            task.Start();
            Console.ReadKey();
        }

        static async void CallSomeMethod()
        {
            Task<string> task = GetVideo();
            string video = await task;

            Task<string> taskintro = AddIntro(video);
            string intro = await taskintro;

            Task<string> taskfinal= AddSummary(intro);
            Console.WriteLine(taskfinal.Result);

        }
        
        static async Task<string> GetVideo(){
            Thread.Sleep(10000);
            string temp = "Main Video";
            return temp;
        }
        static async Task<string> AddIntro(string video){
            Thread.Sleep(20000);
            string temp = "Introduction of Video " + video ;
            return temp;
        }
        static async Task<string> AddSummary(string video)
        {
            Thread.Sleep(30000);
            string temp = video + " Summary of Video";
            return temp;

        }
    }
}
