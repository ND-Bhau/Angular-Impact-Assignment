﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContinuationTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            Task<int> tasktotal = Task.Run(() => Total(2, 4, 6));
            tasktotal.ContinueWith((x) => {
                Console.WriteLine("Total : " + x.Result);
                Console.WriteLine("Average : " + Average(x.Result, 3));
                }
            );
            Console.ReadKey();
        }
        static int Total(int no1,int no2,int no3) {

            return no1 + no2 + no3;
        }
        static int Average(int no1,int no2)
        {
            return (no1 / no2);
        }
    }
}
