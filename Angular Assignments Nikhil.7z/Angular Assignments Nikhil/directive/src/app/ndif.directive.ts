import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[ndIf]'
})
export class NdifDirective {

  _ndif: boolean = true;

  @Input()
  set ndIf(condition: boolean) {
    this._ndif = condition
    this._updateView();
  }

  constructor(private _viewContainer: ViewContainerRef,
    private templateRef: TemplateRef<any>) {
  }

  _updateView() {
    if (this._ndif) {
      this._viewContainer.createEmbeddedView(this.templateRef);
    }
    else {
      this._viewContainer.clear();
    }
  }


}
