import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[ndclass]'
})
export class NdclassDirective {

  @Input() ndclass: string;

  constructor(private el: ElementRef) {
  }

  ngOnInit() {
    this.el.nativeElement.classList.add(this.ndclass);
  }

}
