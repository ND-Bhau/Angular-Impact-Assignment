import { NdclassDirective } from './ndclass.directive';

describe('NdclassDirective', () => {
  it('should create an instance', () => {
    const directive = new NdclassDirective();
    expect(directive).toBeTruthy();
  });
});
