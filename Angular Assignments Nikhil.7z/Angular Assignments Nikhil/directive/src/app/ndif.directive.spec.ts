import { NdifDirective } from './ndif.directive';

describe('NdifDirective', () => {
  it('should create an instance', () => {
    const directive = new NdifDirective();
    expect(directive).toBeTruthy();
  });
});
