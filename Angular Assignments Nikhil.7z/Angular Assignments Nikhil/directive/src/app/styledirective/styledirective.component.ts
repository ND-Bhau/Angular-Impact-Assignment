import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styledirective',
  templateUrl: './styledirective.component.html',
  styleUrls: ['./styledirective.component.css']
})
export class StyledirectiveComponent implements OnInit {

  people = [
    {
      "name": "Douglas  Pace",
      "country": 'UK'
    },
    {
      "name": "Mcleod  Mueller",
      "country": 'USA'
    },
    {
      "name": "Day  Meyers",
      "country": 'HK'
    },
    {
      "name": "Aguirre  Ellis",
      "country": 'UK'
    },
    {
      "name": "Cook  Tyson",
      "country": 'USA'
    }
  ];


  constructor() { }

  ngOnInit(): void {
  }

  changecolor(c) {
    if (c == "UK") {
      return 'green';
    }
    else if (c == "USA") {
      return 'blue';
    }
    else if (c == "HK") {
      return 'red';
    }
    else {
      return 'grey';
    }
  }

}
