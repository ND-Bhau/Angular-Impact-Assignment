import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { DirectiveComponent } from './directive/directive.component';
import { SwitchdirectiveComponent } from './switchdirective/switchdirective.component';
import { EmployeesComponent } from './employees/employees.component';
import { StyledirectiveComponent } from './styledirective/styledirective.component';
import { NdifDirective } from './ndif.directive';
import { NdclassDirective } from './ndclass.directive';

@NgModule({
  declarations: [
    AppComponent,
    DirectiveComponent,
    SwitchdirectiveComponent,
    EmployeesComponent,
    StyledirectiveComponent,
    NdifDirective,
    NdclassDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
