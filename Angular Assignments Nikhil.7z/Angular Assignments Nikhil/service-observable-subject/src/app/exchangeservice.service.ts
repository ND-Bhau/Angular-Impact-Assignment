import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExchangeserviceService {

  SharingVariable = new Subject();

  UsingBehaviorsubject = new BehaviorSubject('Hi from Service');

  constructor() { }
}
