import { Component, OnInit } from '@angular/core';
import { ExchangeserviceService } from '../exchangeservice.service';

@Component({
  selector: 'app-receiver',
  templateUrl: './receiver.component.html',
  styleUrls: ['./receiver.component.css']
})
export class ReceiverComponent implements OnInit {
  Subjectdisplay2: any;
  BehaviorSubjectdisplay2: any;


  constructor(private exchangeserviceService: ExchangeserviceService) {
    this.exchangeserviceService.SharingVariable.subscribe(x => {
      this.Subjectdisplay2 = x;
    })
    this.exchangeserviceService.UsingBehaviorsubject.subscribe(x => {
      this.BehaviorSubjectdisplay2 = x;
    })
  }

  ngOnInit(): void {
  }

  SendData(msg) {
    this.exchangeserviceService.SharingVariable.next(msg);
    this.exchangeserviceService.UsingBehaviorsubject.next(msg);
  }

}
