import { Component, OnInit } from '@angular/core';
import { ExchangeserviceService } from '../exchangeservice.service';

@Component({
  selector: 'app-sender',
  templateUrl: './sender.component.html',
  styleUrls: ['./sender.component.css']
})
export class SenderComponent implements OnInit {

  Subjectdisplay1: any;
  BehaviorSubjectdisplay1: any;


  constructor(private exchangeserviceService: ExchangeserviceService) {
    this.exchangeserviceService.SharingVariable.subscribe(x => {
      this.Subjectdisplay1 = x;
    })
    this.exchangeserviceService.UsingBehaviorsubject.subscribe(x => {
      this.BehaviorSubjectdisplay1 = x;
    })
  }

  ngOnInit(): void {
  }

  SendData(msg) {
    this.exchangeserviceService.SharingVariable.next(msg);
    this.exchangeserviceService.UsingBehaviorsubject.next(msg);
  }
}
