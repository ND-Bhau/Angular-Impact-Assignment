import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { DatasourceService } from './datasource.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'service-observable';
  Numbers: any = [];
  Numbers1: any = [];


  numberlist: Observable<any>;



  constructor(private datasource: DatasourceService) { }

  ngOnInit() {
    this.datasource.GetNumbersUsingForm().subscribe(x => {
      this.Numbers.push(x);
      // console.log(x);
    });

    this.datasource.GetNumbersUsingOF().subscribe(x => {
      this.Numbers1 = x;
    });

    this.numberlist = this.datasource.GetNumberUsingAsyncPipe();


  }
}
