import { Injectable } from '@angular/core';
import { Observable, from, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatasourceService {

  of_Numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  form_Numbers = from([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);

  constructor() { }

  GetNumbersUsingOF() {
    return of(this.of_Numbers).pipe(x => (x));
  }

  GetNumbersUsingForm() {
    return this.form_Numbers;
  }

  GetNumberUsingAsyncPipe() {
    return new Observable(x => {
      x.next(this.of_Numbers);
    });
  }
}
