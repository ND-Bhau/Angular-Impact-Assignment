import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-downloads',
  templateUrl: './downloads.component.html',
  styleUrls: ['./downloads.component.css']
})
export class DownloadsComponent implements OnInit {

  friendslist = [];
  constructor(private sharedservice: SharedService) {

    this.friendslist = [
      'ab',
      'cd',
      'ef',
      'gh',
      'sdsd',
      'dd',
      'sds',
      'fdfd',
      'sdsd',
      'sdsd',
      'sdad',
      'sds'
    ]
  }
  ngOnInit(): void {
    console.log('lenght frorm downloads : ' + this.friendslist.length);
    this.sharedservice.length.next(this.friendslist.length)
  }

}
