import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FriendComponent } from './friend/friend.component';

import { FriendsComponent } from './friends.component';

const routes: Routes = [
  { path: '', component: FriendsComponent },
  { path: 'friend/:name', component: FriendComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FriendsRoutingModule { }
