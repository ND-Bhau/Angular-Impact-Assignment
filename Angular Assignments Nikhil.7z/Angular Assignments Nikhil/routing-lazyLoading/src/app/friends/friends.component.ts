import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {

  friendslist = [];
  constructor() {

    this.friendslist = [
      'Nikhil',
      'Suresh',
      'Ramesh',
      'Paresh',
      'Jighesh',
      'Ravi',
      'Mayur',
      'Mango',
      'Niranjan',
      'Nikita',
      'Soniya',
      'Sachin'
    ]
  }

  ngOnInit(): void {
    var ab = this.friendslist.length;
    console.log('lenthg inside friends component : ' + ab );
    // this.sharedservice.length.next(ab);
  }

}
