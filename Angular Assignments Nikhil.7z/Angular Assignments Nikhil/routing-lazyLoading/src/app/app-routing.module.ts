import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthgardGuard } from './authgard.guard';
import { DownloadsComponent } from './downloads/downloads.component';
import { FriendsComponent } from './friends/friends.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'or/home' },
  { path: 'or/home', component: HomeComponent },
  { path: 'downloads', component: DownloadsComponent },
  { path: 'friends', loadChildren: () => import('./friends/friends.module').then(m => m.FriendsModule), canActivate: [AuthgardGuard] },
  { path: '**', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
