import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { FriendsComponent } from './friends/friends.component';
import { SharedService } from './shared.service';

@Injectable({
  providedIn: 'root'
})
export class AuthgardGuard implements CanActivate {

  constructor(private router: Router, private sharedservice: SharedService) { }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    let length = 11;

    var friends = new FriendsComponent();
    length = friends.friendslist.length;
    console.log(friends.friendslist.length);

    console.log()

    if (length > 10) {
      return true;
    }

    this.redirectuser();
    return false;
  }

  redirectuser() {
    this.router.navigate(['/or/home']);
  }
}
