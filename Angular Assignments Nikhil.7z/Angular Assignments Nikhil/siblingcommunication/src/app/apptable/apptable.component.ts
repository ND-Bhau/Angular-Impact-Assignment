import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-apptable',
  templateUrl: './apptable.component.html',
  styleUrls: ['./apptable.component.css']
})
export class ApptableComponent implements OnInit {

  @Input() keyword: string;

  data = [];
  items = [];
  constructor() {
    this.data = [
      { name: "nik", age: "10", post: "Jr Developer" },
      { name: "mango", age: "30", post: "Sr Developer" },
      { name: "Radha", age: "20", post: "Intern" },
      { name: "Pande", age: "40", post: "sr Manager" },
      { name: "Aniket", age: "50", post: "CEO" }
    ];

    this.keyword = '';
  }

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.items = [];
    this.data.forEach(a => {
      if (a.name.search(this.keyword) != -1 || a.age.search(this.keyword) != -1 || a.post.search(this.keyword) != -1) {
        this.items.push(a);
      }
    });
  }

  ngDoCheck() {
    this.load();
  }

}
