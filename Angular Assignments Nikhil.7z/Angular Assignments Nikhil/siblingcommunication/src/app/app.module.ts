import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppsearchComponent } from './appsearch/appsearch.component';
import { ApptableComponent } from './apptable/apptable.component';

@NgModule({
  declarations: [
    AppComponent,
    AppsearchComponent,
    ApptableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
