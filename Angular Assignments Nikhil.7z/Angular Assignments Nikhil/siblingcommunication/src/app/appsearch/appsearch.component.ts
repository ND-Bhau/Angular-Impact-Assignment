import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-appsearch',
  templateUrl: './appsearch.component.html',
  styleUrls: ['./appsearch.component.css']
})
export class AppsearchComponent implements OnInit {
  @Output() ForParent: EventEmitter<string>;

  constructor() {
    this.ForParent = new EventEmitter();
  }

  ngOnInit(): void {
  }

  searchcheck(value) {
    this.ForParent.emit(value);
  }
}
