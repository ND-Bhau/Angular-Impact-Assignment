import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Car } from '../car';
import { CarsServiceService } from '../cars-service.service';

@Component({
  selector: 'app-addcar',
  templateUrl: './addcar.component.html',
  styleUrls: ['./addcar.component.css']
})
export class AddcarComponent implements OnInit {

  constructor(private route: ActivatedRoute, private router: Router, private carservice: CarsServiceService) {
    this.cars = new Car();
  }
  id: number;

  cars: Car;


  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    if (this.id != undefined && this.id != 0) {
      this.getCarbyId(this.id);
    }
  }

  getCarbyId(id) {
    this.carservice.getCarByID(id).subscribe(result => {
      this.cars = result;
    })
  }

  save() {
    if (this.id != undefined && this.id != 0) {
      this.carservice.Editcar(this.id, this.cars).subscribe(result => {
        this.loadpage();
      })
    } else {
      this.carservice.Savecar(this.cars).subscribe(result => {
        this.loadpage();
      })
    }
  }

  loadpage() {
    this.router.navigate(['/cars']);
  }


}
