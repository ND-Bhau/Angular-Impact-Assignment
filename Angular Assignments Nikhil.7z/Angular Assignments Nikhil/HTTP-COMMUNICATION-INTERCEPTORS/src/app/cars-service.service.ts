import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Car } from './car';

@Injectable({
  providedIn: 'root'
})
export class CarsServiceService {

  constructor(private http: HttpClient) { }

  APIURL = "http://localhost:3000/cars";


  getAllCars(): Observable<Car> {
    return this.http.get<Car>(this.APIURL).pipe(catchError(this.handleError));
  }

  getCarByID(id): Observable<Car> {
    return this.http.get<Car>(this.APIURL + "/" + id).pipe(catchError(this.handleError));
  }

  getCarBybrand(brand): Observable<Car> {
    return this.http.get<Car>(this.APIURL + "?brand=" + brand).pipe(catchError(this.handleError));
  }

  Savecar(car) {
    return this.http.post(this.APIURL, car).pipe(catchError(this.handleError));
  }

  Editcar(id, car) {
    return this.http.put(this.APIURL + "/" + id, car).pipe(catchError(this.handleError));
  }

  deleteCar(id) {
    return this.http.delete(this.APIURL + "/" + id).pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
    }
    // Return an observable with a user-facing error message.
    return throwError(() => new Error('Something bad happened; please try again later.'));
  }
}

