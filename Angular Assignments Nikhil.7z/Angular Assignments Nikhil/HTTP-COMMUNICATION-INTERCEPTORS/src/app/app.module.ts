import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AddcarComponent } from './addcar/addcar.component';
import { FormsModule } from '@angular/forms';
import { CarsComponent } from './cars/cars.component';
import { LogingInterceptor } from './loging.interceptor';
import { AddheaderInterceptor } from './addheader.interceptor';
import { ConvertstringInterceptor } from './convertstring.interceptor';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    AddcarComponent,
    CarsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: LogingInterceptor,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: AddheaderInterceptor,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: ConvertstringInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
