import { Component } from '@angular/core';
import { Car } from './car';
import { CarsServiceService } from './cars-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'HTTP-COMMUNICATION-INTERCEPTORS';
  cars: any;
  constructor(private carservice: CarsServiceService) { }

  ngOnInit() {
    this.carservice.getAllCars().subscribe(result => {
      this.cars = result;
    })
  }

  Addcar() {

  }
}
