import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcarComponent } from './addcar/addcar.component';
import { AppComponent } from './app.component';
import { CarsComponent } from './cars/cars.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'cars' },
  { path: 'cars', component: CarsComponent },
  { path: 'addcar', component: AddcarComponent },
  { path: 'addcar/:id', component: AddcarComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
