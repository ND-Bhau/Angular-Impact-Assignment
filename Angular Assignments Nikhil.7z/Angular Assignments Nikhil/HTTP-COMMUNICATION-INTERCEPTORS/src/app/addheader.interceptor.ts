import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

@Injectable()
export class AddheaderInterceptor implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(this.addheader(request));
  }

  addheader(request: HttpRequest<unknown>) {
    if (request.method == "POST") {
      let req = request.clone();
      console.log(req)

      return request.clone({
        setHeaders: {
          context: 'IMPACT Angular Assignments'
        }
      })
    }
    else {
      return request;
    }
  }
}
