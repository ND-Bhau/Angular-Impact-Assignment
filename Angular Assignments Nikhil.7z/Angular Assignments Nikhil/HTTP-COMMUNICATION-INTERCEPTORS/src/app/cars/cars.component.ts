import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../car';
import { CarsServiceService } from '../cars-service.service';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {

  cars: any;
  constructor(private carservice: CarsServiceService, private router: Router) { }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.carservice.getAllCars().subscribe(result => {
      this.cars = result;
    })
  } 

  Addcar() {
    this.router.navigate(['/addcar']);
  }

  delete(id) {
    this.carservice.deleteCar(id).subscribe(x => {
      this.loadpage();
    })
  }

  loadpage() {
    // this.router.navigate(['/addcar']);
    location.reload();
  }

  SearchByid(id) {
    this.carservice.getCarByID(id).subscribe(result => {
      this.cars = [];
      this.cars.push(result);
    });
  }

  SearchBybrand(brand) {
    this.carservice.getCarBybrand(brand.trim()).subscribe(result => {
      this.cars = result;
    });
    

  }




}
