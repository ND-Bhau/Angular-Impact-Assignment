import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class ConvertstringInterceptor implements HttpInterceptor {

  constructor() { }

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(req).pipe(map((event: HttpEvent<any>) => {
      if (req.method == "GET") {
        if (event instanceof HttpResponse) {
          event = event.clone({ body: this.ConvertToString(event.body) });
        }
      }
      return event;
    }));
  }

  ConvertToString(a) { console.log(JSON.stringify(a)) }

}
