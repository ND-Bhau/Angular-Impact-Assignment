import { TestBed } from '@angular/core/testing';

import { ConvertstringInterceptor } from './convertstring.interceptor';

describe('ConvertstringInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      ConvertstringInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: ConvertstringInterceptor = TestBed.inject(ConvertstringInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
