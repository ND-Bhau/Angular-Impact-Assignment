export class Car {
    id: number;
    brand: string;
    model: string;
    year: number;
    type: string;
}
