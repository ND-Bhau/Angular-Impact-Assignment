import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NumberListComponentComponent } from './number-list-component/number-list-component.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'numberlist' },
  { path: 'numberlist', component: NumberListComponentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
