import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-number-component',
  templateUrl: './number-component.component.html',
  styleUrls: ['./number-component.component.css']
})
export class NumberComponentComponent implements OnInit {

  @Input() number: number;
  @Input() collection: any;
  constructor() { }

  ngOnInit(): void {
    this.collection = document.querySelectorAll('input');
  }

  SelectAll() {
    let Input = document.querySelectorAll('input');
    Input.forEach(element => {
      element.checked = true;
    });
  }

  SelectODDNumber() {
    let Input = document.querySelectorAll('input');
    Input.forEach(element => {
      if (Number(element.value) % 2 != 0) {
        element.checked = true;
      }
      else{
        element.checked = false;
      }
    });
  }

}
