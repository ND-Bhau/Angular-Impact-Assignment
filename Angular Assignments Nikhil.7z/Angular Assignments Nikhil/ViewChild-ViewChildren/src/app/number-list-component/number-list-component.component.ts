import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { NumberComponentComponent } from '../number-component/number-component.component';

@Component({
  selector: 'app-number-list-component',
  templateUrl: './number-list-component.component.html',
  styleUrls: ['./number-list-component.component.css']
})
export class NumberListComponentComponent implements OnInit {

  @ViewChild(NumberComponentComponent, { static: true }) Number: NumberComponentComponent;
  // @ViewChildren(NumberComponentComponent) checkboxes: QueryList<ElementRef>;

  numberlist = [];
  constructor() { }

  ngOnInit(): void {
    this.Number = new NumberComponentComponent();
    this.numberlist = this.getlist(10);

  }

  ngAfterViewInit() {
    // this.checkboxes.forEach(x => {
    //   x.nativeElement.checked = true;
    //   // console.log(x.nativeElement.collection.checked = true);
    // })
  }

  getlist(n) {
    let array = [];
    for (let i = 1; i <= n; i++) {
      array.push(i);
    }
    return array;
  }


  SelectAll() {
    this.Number.SelectAll();

    // this.checkboxes.forEach(x => {
    //   x.collection.checked = true;
    //   console.log(x.collection.value);
    // })
  }

  OddNumber() {
    this.Number.SelectODDNumber();
  }
}
