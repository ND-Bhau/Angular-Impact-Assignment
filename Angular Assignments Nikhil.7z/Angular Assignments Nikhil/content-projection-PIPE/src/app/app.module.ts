import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StylishButtonComponent } from './stylish-button/stylish-button.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { PipeComponent } from './pipe/pipe.component';
import { FilterComponent } from './filter/filter.component';
import { FilterPipe } from './filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    StylishButtonComponent,
    TechnologiesComponent,
    PipeComponent,
    FilterComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
