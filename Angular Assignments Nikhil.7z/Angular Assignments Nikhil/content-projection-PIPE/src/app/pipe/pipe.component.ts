import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {

  content:string="Pipes in Angular";
  dob:number = Date.now();
  amount:number = 12.97;
  pi: number = 3.14159265359;
  profitPer:number =  1.798;

  constructor() { }

  ngOnInit(): void {
  }

}
