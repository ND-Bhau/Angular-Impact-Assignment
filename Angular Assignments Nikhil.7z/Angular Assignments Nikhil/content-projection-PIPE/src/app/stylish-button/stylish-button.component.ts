import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stylish-button',
  templateUrl: './stylish-button.component.html',
  styleUrls: ['./stylish-button.component.css']
})
export class StylishButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
