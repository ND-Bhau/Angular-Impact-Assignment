import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StylishButtonComponent } from './stylish-button.component';

describe('StylishButtonComponent', () => {
  let component: StylishButtonComponent;
  let fixture: ComponentFixture<StylishButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StylishButtonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StylishButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
