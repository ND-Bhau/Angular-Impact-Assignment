import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  // transform(value: unknown, ...args: unknown[]): unknown {
  //   return null;
  // }

  transform(NameList: any, value: string): string {
    let names;
    if (value != undefined && value != null) {
      names = NameList.filter(x => value.toLowerCase() == x.toLowerCase());
    }
    else {
      names = NameList;
    }
    return names;
  }

}
