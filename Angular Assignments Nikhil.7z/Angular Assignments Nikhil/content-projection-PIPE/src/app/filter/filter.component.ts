import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {

  PersonName = [];
  constructor() {
    this.PersonName = [
      'Nikhil',
      'Paresh',
      'Ramesh',
      'Suresh',
      'Hitesh',
      'Gitesh',
      'Thughesh',
      'Naresh',
      'Manish',
      'Archer'
    ];

    
  }

  ngOnInit(): void {
  }

}
