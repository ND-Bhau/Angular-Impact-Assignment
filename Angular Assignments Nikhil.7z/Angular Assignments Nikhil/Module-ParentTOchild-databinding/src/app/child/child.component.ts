import { Component, Input, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() FromParent = '';
  @Output() ForParent: EventEmitter<string>;

  forparentstrinng = 'love form child';

  constructor() {
    this.FromParent = '';
    this.ForParent = new EventEmitter();
  }

  ngOnInit(): void {
  }

  addemmiter() {
    this.ForParent.emit(this.forparentstrinng);
  }

}
