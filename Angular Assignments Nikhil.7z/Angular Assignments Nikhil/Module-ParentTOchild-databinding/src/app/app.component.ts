import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment-Module-PToC-Communication';
  message: string = 'Message of the Day';
  todo: string = 'Enter the message of the day';
  forchange: string;

  ForChild = 'form parent';

  formchild = '';

  cngmsg() {
    this.message = 'Tip of the Day';
  }
  message1: string = 'Message of the Day1';

  ngOnInit() {
    this.forchange = this.message1;
  }

  binds() {
    this.message1 = this.forchange;
  }

  collectdatafromchild(event)
  {
    this.formchild = event;
  }
}
