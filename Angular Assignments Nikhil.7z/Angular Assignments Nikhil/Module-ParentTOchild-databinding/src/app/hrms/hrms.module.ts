import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { HrComponent } from './hr/hr.component';



@NgModule({
  declarations: [EmployeeComponent, HrComponent],
  imports: [
    CommonModule
  ],
  exports: [EmployeeComponent]
})
export class HrmsModule { }
